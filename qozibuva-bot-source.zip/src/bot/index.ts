import TelegramBot from "node-telegram-bot-api";
import { logger } from "../lib/logger";
import { setupHandlers, warmPdfCache } from "./handlers";

const TOKEN = process.env["TELEGRAM_BOT_TOKEN"];

if (!TOKEN) {
  throw new Error("TELEGRAM_BOT_TOKEN muhit o'zgaruvchisi topilmadi!");
}

let bot: TelegramBot | null = null;

export async function startBot(): Promise<void> {
  if (bot) return;

  // Avval webhook o'chiramiz (deployed versiya bilan ziddiyatni oldini olish)
  const tempBot = new TelegramBot(TOKEN, { polling: false });
  try {
    await tempBot.deleteWebHook({ drop_pending_updates: true });
    logger.info("Webhook o'chirildi, polling boshlanyapti");
  } catch (err) {
    logger.warn({ err }, "Webhook o'chirishda xato (ehtimol yo'q edi)");
  }

  bot = new TelegramBot(TOKEN, { polling: true });

  setupHandlers(bot);

  bot.setMyCommands([
    { command: "start", description: "Botni ishga tushirish" },
    { command: "help",  description: "Yordam" },
    { command: "clean", description: "Chatni tozalash" },
  ]).catch((err) => logger.error({ err }, "setMyCommands xato"));

  fetch(`https://api.telegram.org/bot${TOKEN}/setChatMenuButton`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ menu_button: { type: "commands" } }),
  }).catch((err) => logger.error({ err }, "setChatMenuButton xato"));

  bot.on("polling_error", (err) => {
    logger.error({ err }, "Telegram polling error");
  });

  bot.on("error", (err) => {
    logger.error({ err }, "Telegram bot error");
  });

  logger.info("Telegram bot ishga tushdi (polling mode)");

  warmPdfCache().catch((err) => logger.error({ err }, "PDF cache warm qilishda xato"));
}

export function getBot(): TelegramBot | null {
  return bot;
}
