import app from "./app";
import { logger } from "./lib/logger";
import { startBot } from "./bot/index";

process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "Unhandled promise rejection — bot davom etadi");
});

process.on("uncaughtException", (err) => {
  logger.error({ err }, "Uncaught exception — bot davom etadi");
});

if (process.env["NODE_ENV"] === "production") {
  startBot().catch((err) => {
    logger.error({ err }, "Bot ishga tushishda xato");
  });
} else {
  logger.info("Development rejimi — bot polling o'chirilgan (Railway da ishlaydi)");
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
